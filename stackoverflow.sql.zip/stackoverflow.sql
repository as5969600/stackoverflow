-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2021 at 09:42 AM
-- Server version: 5.1.54
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `stackoverflow`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `password`) VALUES
('akash.com', 'Akash123');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE IF NOT EXISTS `answer` (
  `question_code` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `answer` blob NOT NULL,
  `date` varchar(255) NOT NULL,
  `sn` int(255) NOT NULL,
  `answer_code` varchar(255) NOT NULL,
  `like_count` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`question_code`, `email`, `answer`, `date`, `sn`, `answer_code`, `like_count`) VALUES
('PHM4Uc_5', 'akash.com', 0x712e2c6d77643b6c6d733b6c64207373643b6b6c6d73713b6f64712071776c3b646d643b7177203b6c776b73643b2077773b6c646b3b71776420773b6c646d3b7771203b6c2c3b7820643b6c77646b, 'Mon May 04 10:18:34 PKT 2020', 4, 'NxSpTY_4', 1),
('PHM4Uc_5', 'akash.com', 0x6768666467747278206a6866797566206a687966757966206867756b206b6a626775696b206b6a626a, 'Mon May 04 10:06:43 PKT 2020', 3, 'r7fLpE_3', 0),
('IRFBuV_3', 'akash.com', 0x6b6c3b646a666f706a72657720666b6c65776a6e696f666f666965776a74696f2066696f65776a66696f70657720696b6f666a706f6977652066696f776a6677, 'Sun May 03 11:17:02 PKT 2020', 2, 'LBxF6C_2', 2),
('KAFje6_6', 'ankur@gmail.com', 0x73786a6e786575696675696f656675696f206a6b666e656469756f666e6a6b646e6f69652065696f666e6f6965662075696f666e696f6566, 'Sun May 03 11:16:13 PKT 2020', 1, 'k35Iq2_1', 3),
('PHM4Uc_5', 'akash.com', 0x7364696f75637064732064696f6c6173756466706577206f6c69756a7077652064696f6873646f6369646e7363646f6c6973756a6320736f696c6a736169636f2063696f6c736a63206f6c6973616a636f696173, 'Mon May 04 10:35:03 PKT 2020', 5, 'w207Rm_5', 0),
('x6ik2U_4', 'akash.com', 0x6274676b676d74672067626c6b6d67686c7420686c6b67626b6c6d626720626c666b626d666c6b62206c6b6d62646c6b656565656565676c6b68656720686c656b6865, 'Wed May 06 19:03:13 PKT 2020', 6, 'lWv0nZ_6', 0);

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `sn` int(11) NOT NULL,
  `code` varchar(11) NOT NULL,
  `category` varchar(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`sn`, `code`, `category`) VALUES
(1, 'CO0kPs_1', 'java'),
(2, '5LPdAV_2', 'c++'),
(3, 'L0U5KW_3', 'c'),
(4, '61kbth_4', 'php'),
(5, 'pon3AT_5', 'angular'),
(6, 'HcPMuU_6', 'window'),
(7, 'q34kYy_7', 'jsp');

-- --------------------------------------------------------

--
-- Table structure for table `interest`
--

CREATE TABLE IF NOT EXISTS `interest` (
  `question_code` varchar(255) NOT NULL,
  `answer_code` varchar(255) NOT NULL,
  `tos` varchar(255) NOT NULL,
  `froms` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `interest`
--

INSERT INTO `interest` (`question_code`, `answer_code`, `tos`, `froms`, `date`) VALUES
('IRFBuV_3', 'LBxF6C_2', 'ankur@gmail.com', 'azhar.com', 'Sun May 03 12:36:33 PKT 2020'),
('KAFje6_6', 'k35Iq2_1', 'akash.com', 'azhar.com', 'Sun May 03 12:36:20 PKT 2020'),
('KAFje6_6', 'k35Iq2_1', 'akash.com', 'akash.com', 'Sun May 03 11:59:58 PKT 2020'),
('KAFje6_6', 'k35Iq2_1', 'akash.com', 'ankur@gmail.com', 'Sun May 03 11:53:13 PKT 2020'),
('IRFBuV_3', 'LBxF6C_2', 'ankur@gmail.com', 'ankur@gmail.com', 'Sun May 03 11:52:38 PKT 2020'),
('PHM4Uc_5', 'NxSpTY_4', 'akash.com', 'akash.com', 'Thu May 07 10:48:21 PKT 2020');

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE IF NOT EXISTS `question` (
  `sn` int(11) NOT NULL,
  `code` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `question` varchar(255) NOT NULL,
  `descrip` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `comment` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`sn`, `code`, `email`, `question`, `descrip`, `date`, `comment`) VALUES
(6, 'KAFje6_6', 'akash.com', '     what is dyamnic web pages ?', 'jkhiuhqoishd wqjkbdiuhqiu jkqbiuowdhdiuoq', 'Thu Apr 30 18:25:26 PKT 2020', 1),
(5, 'PHM4Uc_5', 'akash.com', '   what is c++ ?', 'jyuydrdftgkih mjguigui ,mhkihikdc bkjhkuc hbkjhuk', 'Thu Apr 30 09:34:05 PKT 2020', 3),
(4, 'x6ik2U_4', 'akash.com', '   what is compiler in javascript in java jva ?', 'hagyugclkjoi kljhoiucho jklhiojdows jpoisjdo9d iolsdjcio', 'Wed Apr 29 21:30:57 PKT 2020', 1),
(3, 'IRFBuV_3', 'ankur@gmail.com', 'what is compiler?', 'sjdkfszdkjhcnkuhuqewihrfbkweb', 'Thu Feb 20 00:43:43 PKT 2020', 1),
(2, 'FIudY6_2', 'akash.com', '  who is akash ?', 'lfdslkfksadfnsdf klwhiugiudw uiwhuiohio uiwhsuichoiw', 'Sun Apr 26 18:32:04 PKT 2020', 0),
(1, 'GZcs8Y_1', 'akash.com', 'what is c?', 'nsdkhnoiuhoeiwhoif', 'Sun Feb 09 21:17:39 PKT 2020', 0),
(7, 'VLgQAG_7', 'akash.com', 'what is c programming', 'kmenjf iojdioe eofiorf oieiofe foiejfioe', 'Sat Aug 22 09:08:52 PKT 2020', 0);

-- --------------------------------------------------------

--
-- Table structure for table `question_category`
--

CREATE TABLE IF NOT EXISTS `question_category` (
  `category_code` varchar(255) NOT NULL,
  `question_code` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question_category`
--

INSERT INTO `question_category` (`category_code`, `question_code`, `category`) VALUES
('L0U5KW_3', 'KAFje6_6', 'c'),
('L0U5KW_3', 'VLgQAG_7', 'c'),
('5LPdAV_2', 'KAFje6_6', 'c++'),
('q34kYy_7', 'PHM4Uc_5', 'jsp'),
('HcPMuU_6', 'PHM4Uc_5', 'window'),
('pon3AT_5', 'PHM4Uc_5', 'angular'),
('61kbth_4', 'PHM4Uc_5', 'php'),
('CO0kPs_1', 'VLgQAG_7', 'java'),
('L0U5KW_3', 'IRFBuV_3', 'c'),
('5LPdAV_2', 'IRFBuV_3', 'c++'),
('CO0kPs_1', 'x6ik2U_4', 'java'),
('5LPdAV_2', 'x6ik2U_4', 'c++'),
('pon3AT_5', 'x6ik2U_4', 'angular'),
('L0U5KW_3', 'x6ik2U_4', 'c'),
('CO0kPs_1', 'IRFBuV_3', 'java'),
('pon3AT_5', 'GZcs8Y_1', 'angular'),
('L0U5KW_3', 'GZcs8Y_1', 'c'),
('L0U5KW_3', 'PHM4Uc_5', 'c'),
('5LPdAV_2', 'PHM4Uc_5', 'c++'),
('CO0kPs_1', 'PHM4Uc_5', 'java'),
('61kbth_4', 'x6ik2U_4', 'php'),
('HcPMuU_6', 'x6ik2U_4', 'window'),
('q34kYy_7', 'x6ik2U_4', 'jsp'),
('q34kYy_7', 'FIudY6_2', 'jsp'),
('CO0kPs_1', 'FIudY6_2', 'java'),
('5LPdAV_2', 'FIudY6_2', 'c++'),
('L0U5KW_3', 'FIudY6_2', 'c'),
('61kbth_4', 'FIudY6_2', 'php'),
('pon3AT_5', 'FIudY6_2', 'angular'),
('HcPMuU_6', 'FIudY6_2', 'window');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE IF NOT EXISTS `register` (
  `sn` int(11) NOT NULL,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`sn`, `code`, `name`, `email`, `password`) VALUES
(0, 'jdKGkZ', 'akash sharma', 'akash.com', '12345'),
(1, 'ruVNeG_1', 'azhar', 'azhar.com', 'Az123'),
(2, '0NXEnx_2', 'ankur', 'ankur@gmail.com', '123');
